from core.blueprints.base_blueprint import BaseBlueprint

zenodo_bp = BaseBlueprint('zenodo', __name__, template_folder='templates')

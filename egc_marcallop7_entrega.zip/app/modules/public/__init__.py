from core.blueprints.base_blueprint import BaseBlueprint

public_bp = BaseBlueprint('public', __name__, template_folder='templates')
